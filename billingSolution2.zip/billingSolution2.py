# Priya Priya

import pymongo

connection = pymongo.MongoClient("mongodb+srv://Anshu:anshu123@billingsolution.kkjaf.mongodb.net/BillingSolution?retryWrites=true&w=majority")
database = connection['BillingSolution']

collection = database['OrderDetail']
collection2 = database['TransactionInformation']

data = [{"Order Id": 1, "Order Place date": "11/07/2020"},
        {"Order Id": 2, "Order Place date": "04/04/2020"},
        {"Order Id": 3, "Order Place date": "21/03/2020"},
        {"Order Id": 4, "Order Place date": "21/12/2019"},
        {"Order Id": 5, "Order Place date": "11/10/2019"},
        {"Order Id": 6, "Order Place date": "22/08/2020"},
        {"Order Id": 7, "Order Place date": "04/08/2020"},
        {"Order Id": 8, "Order Place date": "28/05/2020"},
        {"Order Id": 9, "Order Place date": "12/11/2019"},
        {"Order Id": 10, "Order Place date": "28/03/2020"}]


data2 = [{"Transaction type": "Payment", "Transaction Method": "Cash on delivery", "Account No": "", "Billing Address": "98 Anthia Drive, North York, Ontario - M9L1K8"},
         {"Transaction type": "Payment", "Transaction Method": "Credit/Debit", "Account No": 14587956, "Billing Address": "54 Keefer place, Richmond, Vancouver, V6L0B8"},
         {"Transaction type": "Refund",  "Transaction Method": "Gift Card", "Account No": 45254686, "Billing Address": "102, Dean Park Road, Scarborough, Toronto - M1L8K8"},
         {"Transaction type": "Exchange", "Transaction Method": "Credit/Debit", "Account No": 14586825, "Billing Address": "102 St. Clair, Toronto, Ontario - M1L8R8 "},
         {"Transaction type": "Payment", "Transaction Method": "Cash on delivery", "Account No": "", "Billing Address": "747 kings street Montreal, C9I2G4"},
         {"Transaction type": "Payment", "Transaction Method": "Credit/Debit", "Account No": 47581236, "Billing Address": "10, Red River Crescent, Scarborough, Ontario - M1B1Z6"},
         {"Transaction type": "Payment", "Transaction Method": "Cash on delivery", "Account No": "", "Billing Address": "41, Brimley Road, Ontario - M1B1R4 "},
         {"Transaction type": "Refund", "Transaction Method": "Gift Card", "Account No": "", "Billing Address": "23, Vellore Woods, Vaughan, Ontario - T2RG4S"},
         {"Transaction type": "Payment", "Transaction Method": "Cash on delivery", "Account No": "", "Billing Address": "1515, 360 Pitfiled Rd, Ontario - M1B1Z6 "},
         {"Transaction type": "Payment", "Transaction Method": "Credit/Debit", "Account No": 74581236, "Billing Address": "10, Rouge river Drive, Scarbourogh , Ontaio - M2RG4S"}]


def insertData(data):
    collection.insert_many(data)

def insertData2(data):
    collection2.insert_many(data)

#insertData(data)
#insertData2(data2)

def readData():
    orders = collection.find()
    transaction = collection2.find()

    print("All data from Order Detail")
    for order in orders:
        print(order)

    print("All data of Transaction Information")
    for trans in transaction:
        print(trans)

#readData()

def updateData():
    collection2.update_one(
        {"Transaction type": "Payment"},
        {
            "$set": {
                "Billing Address": "98 Anthia Drive, Scarborough, Ontario M9L1K8",
            }
        })

    collection.update_one(
        {"Order Id": 1},
        {
            "$set": {
                "Order Place date": "10/07/2020",
            }
        })

#updateData()

def deleteData():
    query = ({"Order Id": 1})
    collection.delete_one(query)

    query1 = ({"Transaction Method": "Cash on delivery"})
    collection2.delete_many(query1)

deleteData()